﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusDbFirst.Models;

namespace BusDbFirst.Controllers
{
    public class BusController : Controller
    {
        // GET: Bus 
        BusEntities1 context = new BusEntities1();
        public ActionResult Index()
        {
            //List<tblBusInfo> result=context.tblBusInfoes.ToList();
            return View((from c in context.tblBusInfoes
                         where c.BoardingPoint == "MUM"
                         select c));
        }
    }
}