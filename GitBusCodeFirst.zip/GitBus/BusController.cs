﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusCodeFirst.Models;
using System.Data.SqlClient;
using System.Data;
using System.Data.Entity;

namespace BusCodeFirst.Controllers
{
    public class BusController : Controller
    {
        // GET: Bus
       BusContext context=new BusContext();
        public ActionResult Index()
        {
            context.BusInfos.ToList();
            return View();
        }
        [HttpPost]
        public void Insert(string BoardingPoint, string TravelDate, decimal Amount, int Rating)
        {
            SqlConnection con = new SqlConnection("data source=SHAFI;database=Bus;integrated security=SSPI");
            SqlCommand cmd = con.CreateCommand();
            con.Open();
            cmd.CommandText = "Execute BusProc @BoardingPoint,@TravelDate,@Amount,@Rating";
            cmd.Parameters.Add("@BoardingPoint", SqlDbType.VarChar, 50).Value = BoardingPoint;
            cmd.Parameters.Add("@TravelDate", SqlDbType.VarChar, 50).Value = TravelDate;
            cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = Amount;
            cmd.Parameters.Add("@Rating", SqlDbType.Int).Value = Rating;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }
    }
}