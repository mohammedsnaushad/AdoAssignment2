﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace BusCodeFirst.Models
{

    public class BusContext : DbContext 
    {
        public BusContext() : base ("name = BusConn")
        {

        }
        public DbSet<BusInfo> BusInfos { get; set; }
    }
}